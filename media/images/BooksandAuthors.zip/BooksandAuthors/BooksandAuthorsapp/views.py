from django.shortcuts import render, redirect
from BooksandAuthorsapp.models import *

def index(request):
    books = Book.objects.all()
    context = {
        'books': books
    }

    return render(request, 'index.html', context)

def showauthor(request, id):
    author = Author.objects.get(id=id)
    books = Book.objects.all()
    context = {
        'author': author,
        'books': books
    }
    return render(request, 'showauthor.html', context)

def showbook(request, id):
    book = Book.objects.get(id=id)
    authors = Author.objects.all()
    context = {
        'book': book,
        'authors': authors
    }
    return render(request, 'showbook.html', context)

def addauthor(request):
    authors = Author.objects.all()
    context = {
        'authors': authors
    }
    return render(request, 'addauthor.html', context)

def processingaddbook(request):
    authorid = request.POST['authorid']
    bookid = request.POST['bookform']
    booktoadd = Book.objects.get(id=bookid)
    authortoaddto = Author.objects.get(id=authorid)
    authortoaddto.books.add(booktoadd)
    return redirect('/authors/'+ authorid)

def processingaddauthor(request):
    authorid = request.POST['authorform']
    bookid = request.POST['bookid']
    authortoadd = Author.objects.get(id=authorid)
    booktoaddto = Book.objects.get(id=bookid)
    booktoaddto.authors.add(authortoadd)
    return redirect('/books/'+ bookid)

def processing1(request):
    first_name = request.POST['firstname']
    last_name = request.POST['lastname']
    notes = request.POST['notes']
    Author.objects.create(first_name=first_name, last_name=last_name, notes=notes)
    return redirect('/authors')

def processing2(request):
    title = request.POST['title']
    desc = request.POST['desc']
    Book.objects.create(title=title, desc=desc)
    return redirect('/')


