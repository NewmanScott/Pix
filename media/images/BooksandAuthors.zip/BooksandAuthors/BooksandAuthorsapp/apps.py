from django.apps import AppConfig


class BooksandauthorsappConfig(AppConfig):
    name = 'BooksandAuthorsapp'
